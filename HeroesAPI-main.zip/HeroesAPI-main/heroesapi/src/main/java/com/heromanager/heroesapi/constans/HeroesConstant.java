package com.heromanager.heroesapi.constans;

public class HeroesConstant {
    public static final String HEROES_ENDPOINT_LOCAL = "/heroes";
    public static final String DYNAMO_ENDPOINT = "http://localhost:8000";
    public static final String DYNAMO_REGION = "sa-east-1";
}
