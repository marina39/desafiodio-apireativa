API de Gerenciamento de Heróis Marvel/DC feito com Spring Framework, banco de dados DynamoDB e testes unitários com JUnit.
